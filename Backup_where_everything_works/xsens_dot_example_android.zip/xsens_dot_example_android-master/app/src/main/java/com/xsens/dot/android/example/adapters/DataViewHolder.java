package com.xsens.dot.android.example.adapters;

public interface DataViewHolder {
}
